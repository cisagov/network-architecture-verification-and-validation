#!/usr/bin/env python3

from navv.network_analysis import main


if __name__ == "__main__":
    main()
